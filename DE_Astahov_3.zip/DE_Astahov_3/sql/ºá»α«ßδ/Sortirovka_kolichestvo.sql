use DE_Astahov_#3
SELECT * FROM Pokypki ORDER BY Kolichestvo