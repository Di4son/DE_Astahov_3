use DE_Astahov_#3
SELECT * FROM Klienty ORDER BY FIO