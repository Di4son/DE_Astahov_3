use DE_Astahov_#3
SELECT * FROM Tovary ORDER BY Nazvaniye_tovara