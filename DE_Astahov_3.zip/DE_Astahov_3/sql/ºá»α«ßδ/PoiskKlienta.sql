use DE_Astahov_#3
SELECT * FROM Klienty
WHERE Pol = '�'