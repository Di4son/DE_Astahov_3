﻿namespace DE_Astahov_3
{
    partial class User_pokypki
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(User_pokypki));
            this.button_nazad = new System.Windows.Forms.Button();
            this.button_sled = new System.Windows.Forms.Button();
            this.button_pred = new System.Windows.Forms.Button();
            this.button_posled = new System.Windows.Forms.Button();
            this.button_pervaya = new System.Windows.Forms.Button();
            this._DE_Astahov__3DataSet = new DE_Astahov_3._DE_Astahov__3DataSet();
            this.pokypkiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pokypkiTableAdapter = new DE_Astahov_3._DE_Astahov__3DataSetTableAdapters.PokypkiTableAdapter();
            this.tableAdapterManager = new DE_Astahov_3._DE_Astahov__3DataSetTableAdapters.TableAdapterManager();
            this.pokypkiDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this._DE_Astahov__3DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pokypkiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pokypkiDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // button_nazad
            // 
            this.button_nazad.BackColor = System.Drawing.Color.LightSalmon;
            this.button_nazad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_nazad.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_nazad.Location = new System.Drawing.Point(541, 138);
            this.button_nazad.Name = "button_nazad";
            this.button_nazad.Size = new System.Drawing.Size(125, 50);
            this.button_nazad.TabIndex = 38;
            this.button_nazad.Text = "Назад";
            this.button_nazad.UseVisualStyleBackColor = false;
            this.button_nazad.Click += new System.EventHandler(this.button_nazad_Click);
            // 
            // button_sled
            // 
            this.button_sled.BackColor = System.Drawing.Color.LightSalmon;
            this.button_sled.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_sled.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_sled.Location = new System.Drawing.Point(276, 138);
            this.button_sled.Name = "button_sled";
            this.button_sled.Size = new System.Drawing.Size(125, 50);
            this.button_sled.TabIndex = 37;
            this.button_sled.Text = "Следующая";
            this.button_sled.UseVisualStyleBackColor = false;
            this.button_sled.Click += new System.EventHandler(this.button_sled_Click);
            // 
            // button_pred
            // 
            this.button_pred.BackColor = System.Drawing.Color.LightSalmon;
            this.button_pred.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_pred.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_pred.Location = new System.Drawing.Point(407, 138);
            this.button_pred.Name = "button_pred";
            this.button_pred.Size = new System.Drawing.Size(131, 50);
            this.button_pred.TabIndex = 36;
            this.button_pred.Text = "Предыдущая";
            this.button_pred.UseVisualStyleBackColor = false;
            this.button_pred.Click += new System.EventHandler(this.button_pred_Click);
            // 
            // button_posled
            // 
            this.button_posled.BackColor = System.Drawing.Color.LightSalmon;
            this.button_posled.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_posled.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_posled.Location = new System.Drawing.Point(148, 138);
            this.button_posled.Name = "button_posled";
            this.button_posled.Size = new System.Drawing.Size(125, 50);
            this.button_posled.TabIndex = 35;
            this.button_posled.Text = "Последняя";
            this.button_posled.UseVisualStyleBackColor = false;
            this.button_posled.Click += new System.EventHandler(this.button_posled_Click);
            // 
            // button_pervaya
            // 
            this.button_pervaya.BackColor = System.Drawing.Color.LightSalmon;
            this.button_pervaya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_pervaya.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_pervaya.Location = new System.Drawing.Point(17, 138);
            this.button_pervaya.Name = "button_pervaya";
            this.button_pervaya.Size = new System.Drawing.Size(125, 50);
            this.button_pervaya.TabIndex = 34;
            this.button_pervaya.Text = "Первая";
            this.button_pervaya.UseVisualStyleBackColor = false;
            this.button_pervaya.Click += new System.EventHandler(this.button_pervaya_Click);
            // 
            // _DE_Astahov__3DataSet
            // 
            this._DE_Astahov__3DataSet.DataSetName = "_DE_Astahov__3DataSet";
            this._DE_Astahov__3DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pokypkiBindingSource
            // 
            this.pokypkiBindingSource.DataMember = "Pokypki";
            this.pokypkiBindingSource.DataSource = this._DE_Astahov__3DataSet;
            // 
            // pokypkiTableAdapter
            // 
            this.pokypkiTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AvtorizacziyaTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.KlientyTableAdapter = null;
            this.tableAdapterManager.PokypkiTableAdapter = this.pokypkiTableAdapter;
            this.tableAdapterManager.TovaryTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = DE_Astahov_3._DE_Astahov__3DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // pokypkiDataGridView
            // 
            this.pokypkiDataGridView.AutoGenerateColumns = false;
            this.pokypkiDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.pokypkiDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.pokypkiDataGridView.DataSource = this.pokypkiBindingSource;
            this.pokypkiDataGridView.Location = new System.Drawing.Point(65, 12);
            this.pokypkiDataGridView.Name = "pokypkiDataGridView";
            this.pokypkiDataGridView.Size = new System.Drawing.Size(548, 111);
            this.pokypkiDataGridView.TabIndex = 39;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id_pokypki";
            this.dataGridViewTextBoxColumn1.HeaderText = "Id_pokypki";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Kolichestvo";
            this.dataGridViewTextBoxColumn2.HeaderText = "Kolichestvo";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Stoimost";
            this.dataGridViewTextBoxColumn3.HeaderText = "Stoimost";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Id_tovar";
            this.dataGridViewTextBoxColumn4.HeaderText = "Id_tovar";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Id_klient";
            this.dataGridViewTextBoxColumn5.HeaderText = "Id_klient";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // User_pokypki
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(678, 200);
            this.Controls.Add(this.pokypkiDataGridView);
            this.Controls.Add(this.button_nazad);
            this.Controls.Add(this.button_sled);
            this.Controls.Add(this.button_pred);
            this.Controls.Add(this.button_posled);
            this.Controls.Add(this.button_pervaya);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "User_pokypki";
            this.Text = "Покупки";
            this.Load += new System.EventHandler(this.User_pokypki_Load);
            ((System.ComponentModel.ISupportInitialize)(this._DE_Astahov__3DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pokypkiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pokypkiDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_nazad;
        private System.Windows.Forms.Button button_sled;
        private System.Windows.Forms.Button button_pred;
        private System.Windows.Forms.Button button_posled;
        private System.Windows.Forms.Button button_pervaya;
        private _DE_Astahov__3DataSet _DE_Astahov__3DataSet;
        private System.Windows.Forms.BindingSource pokypkiBindingSource;
        private _DE_Astahov__3DataSetTableAdapters.PokypkiTableAdapter pokypkiTableAdapter;
        private _DE_Astahov__3DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView pokypkiDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
    }
}