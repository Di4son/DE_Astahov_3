﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DE_Astahov_3
{
    public partial class Admin_tovary : Form
    {
        public Admin_tovary()
        {
            InitializeComponent();
        }

        private void tovaryBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tovaryBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._DE_Astahov__3DataSet);

        }

        private void Admin_tovary_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_DE_Astahov__3DataSet.Tovary". При необходимости она может быть перемещена или удалена.
            this.tovaryTableAdapter.Fill(this._DE_Astahov__3DataSet.Tovary);

        }

        private void button_pervaya_Click(object sender, EventArgs e)
        {
            tovaryBindingSource.MoveFirst();
        }

        private void button_posled_Click(object sender, EventArgs e)
        {
            tovaryBindingSource.MoveLast();
        }

        private void button_sled_Click(object sender, EventArgs e)
        {
            tovaryBindingSource.MoveNext();
        }

        private void button_pred_Click(object sender, EventArgs e)
        {
            tovaryBindingSource.MovePrevious();
        }

        private void button_sohranit_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tovaryBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._DE_Astahov__3DataSet);
        }

        private void button_ydalit_Click(object sender, EventArgs e)
        {
            tovaryBindingSource.RemoveCurrent();
        }

        private void button_dobavit_Click(object sender, EventArgs e)
        {
            tovaryBindingSource.AddNew();
        }

        private void button_nazad_Click(object sender, EventArgs e)
        {
            Admin adm = new Admin();
            adm.Show();
            this.Hide();
        }
    }
}
