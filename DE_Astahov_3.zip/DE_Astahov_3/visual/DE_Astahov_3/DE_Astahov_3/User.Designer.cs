﻿namespace DE_Astahov_3
{
    partial class User
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(User));
            this.button_tovary = new System.Windows.Forms.Button();
            this.button_pokypki = new System.Windows.Forms.Button();
            this.button_klienty = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_nazad = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button_tovary
            // 
            this.button_tovary.BackColor = System.Drawing.Color.LightSalmon;
            this.button_tovary.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_tovary.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_tovary.Location = new System.Drawing.Point(12, 126);
            this.button_tovary.Name = "button_tovary";
            this.button_tovary.Size = new System.Drawing.Size(125, 50);
            this.button_tovary.TabIndex = 8;
            this.button_tovary.Text = "Товары";
            this.button_tovary.UseVisualStyleBackColor = false;
            this.button_tovary.Click += new System.EventHandler(this.button_tovary_Click);
            // 
            // button_pokypki
            // 
            this.button_pokypki.BackColor = System.Drawing.Color.LightSalmon;
            this.button_pokypki.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_pokypki.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_pokypki.Location = new System.Drawing.Point(12, 70);
            this.button_pokypki.Name = "button_pokypki";
            this.button_pokypki.Size = new System.Drawing.Size(125, 50);
            this.button_pokypki.TabIndex = 7;
            this.button_pokypki.Text = "Покупки";
            this.button_pokypki.UseVisualStyleBackColor = false;
            this.button_pokypki.Click += new System.EventHandler(this.button_pokypki_Click);
            // 
            // button_klienty
            // 
            this.button_klienty.BackColor = System.Drawing.Color.LightSalmon;
            this.button_klienty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_klienty.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_klienty.Location = new System.Drawing.Point(12, 14);
            this.button_klienty.Name = "button_klienty";
            this.button_klienty.Size = new System.Drawing.Size(125, 50);
            this.button_klienty.TabIndex = 6;
            this.button_klienty.Text = "Клиенты";
            this.button_klienty.UseVisualStyleBackColor = false;
            this.button_klienty.Click += new System.EventHandler(this.button_klienty_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DE_Astahov_3.Properties.Resources.gamestore;
            this.pictureBox1.Location = new System.Drawing.Point(153, 55);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(146, 142);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // button_nazad
            // 
            this.button_nazad.BackColor = System.Drawing.Color.LightSalmon;
            this.button_nazad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_nazad.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_nazad.Location = new System.Drawing.Point(12, 182);
            this.button_nazad.Name = "button_nazad";
            this.button_nazad.Size = new System.Drawing.Size(125, 50);
            this.button_nazad.TabIndex = 9;
            this.button_nazad.Text = "Назад";
            this.button_nazad.UseVisualStyleBackColor = false;
            // 
            // User
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(314, 242);
            this.Controls.Add(this.button_nazad);
            this.Controls.Add(this.button_tovary);
            this.Controls.Add(this.button_pokypki);
            this.Controls.Add(this.button_klienty);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "User";
            this.Text = "Пользователь";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_tovary;
        private System.Windows.Forms.Button button_pokypki;
        private System.Windows.Forms.Button button_klienty;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_nazad;
    }
}