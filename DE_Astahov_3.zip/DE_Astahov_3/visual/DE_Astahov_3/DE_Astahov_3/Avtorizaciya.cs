﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DE_Astahov_3
{
    public partial class Avtorizaciya : Form
    {
        public Avtorizaciya()
        {
            InitializeComponent();
        }

        private void button_voiti_Click(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection(@"Data Source=DESKTOP-PK4O4LV;Initial Catalog=DE_Astahov_#3;Integrated Security=True"); //Подключение к базе данных
            string query = "Select * from Avtorizacziya Where username = '" + tbUsername.Text.Trim() + "' and password = '" + tbPassword.Text.Trim() + "'"; //Проверка логина и пароля
            SqlDataAdapter sda = new SqlDataAdapter(query, sqlcon);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            if (dtbl.Rows.Count == 1)
            {
                if (tbUsername.Text == "Admin") // Если имя пользователя равно Admin, то он переходит на форму Admin, иначе на форму User
                {
                    Admin ad = new Admin(); //переход к главному меню
                    ad.Show();
                    this.Hide();
                }
                else
                {
                    User us = new User();
                    us.Show();
                    this.Hide();
                }
            }
            else
            {
                MessageBox.Show("Неверно введен логин или пароль"); // Выводит сообщение о том что неверно введен логин или пароль
                tbPassword.Clear();
                tbUsername.Clear();
            }
        }

        private void button_vihod_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }
    }
}
