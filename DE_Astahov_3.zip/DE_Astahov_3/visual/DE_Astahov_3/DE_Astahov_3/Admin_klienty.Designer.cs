﻿namespace DE_Astahov_3
{
    partial class Admin_klienty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin_klienty));
            System.Windows.Forms.Label id_klientLabel;
            System.Windows.Forms.Label fIOLabel;
            System.Windows.Forms.Label polLabel;
            System.Windows.Forms.Label data_rozhdeniyaLabel;
            this._DE_Astahov__3DataSet = new DE_Astahov_3._DE_Astahov__3DataSet();
            this.klientyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.klientyTableAdapter = new DE_Astahov_3._DE_Astahov__3DataSetTableAdapters.KlientyTableAdapter();
            this.tableAdapterManager = new DE_Astahov_3._DE_Astahov__3DataSetTableAdapters.TableAdapterManager();
            this.klientyBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.klientyBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.klientyDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button_pervaya = new System.Windows.Forms.Button();
            this.button_posled = new System.Windows.Forms.Button();
            this.button_pred = new System.Windows.Forms.Button();
            this.button_sled = new System.Windows.Forms.Button();
            this.button_dobavit = new System.Windows.Forms.Button();
            this.button_ydalit = new System.Windows.Forms.Button();
            this.button_sohranit = new System.Windows.Forms.Button();
            this.button_nazad = new System.Windows.Forms.Button();
            this.button_filtr = new System.Windows.Forms.Button();
            this.button_sort = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbPoisk = new System.Windows.Forms.TextBox();
            this.tbFiltr = new System.Windows.Forms.TextBox();
            this.id_klientTextBox = new System.Windows.Forms.TextBox();
            this.fIOTextBox = new System.Windows.Forms.TextBox();
            this.polTextBox = new System.Windows.Forms.TextBox();
            this.data_rozhdeniyaDateTimePicker = new System.Windows.Forms.DateTimePicker();
            id_klientLabel = new System.Windows.Forms.Label();
            fIOLabel = new System.Windows.Forms.Label();
            polLabel = new System.Windows.Forms.Label();
            data_rozhdeniyaLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this._DE_Astahov__3DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientyBindingNavigator)).BeginInit();
            this.klientyBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.klientyDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // _DE_Astahov__3DataSet
            // 
            this._DE_Astahov__3DataSet.DataSetName = "_DE_Astahov__3DataSet";
            this._DE_Astahov__3DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // klientyBindingSource
            // 
            this.klientyBindingSource.DataMember = "Klienty";
            this.klientyBindingSource.DataSource = this._DE_Astahov__3DataSet;
            // 
            // klientyTableAdapter
            // 
            this.klientyTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AvtorizacziyaTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.KlientyTableAdapter = this.klientyTableAdapter;
            this.tableAdapterManager.PokypkiTableAdapter = null;
            this.tableAdapterManager.TovaryTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = DE_Astahov_3._DE_Astahov__3DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // klientyBindingNavigator
            // 
            this.klientyBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.klientyBindingNavigator.BindingSource = this.klientyBindingSource;
            this.klientyBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.klientyBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.klientyBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.klientyBindingNavigatorSaveItem});
            this.klientyBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.klientyBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.klientyBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.klientyBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.klientyBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.klientyBindingNavigator.Name = "klientyBindingNavigator";
            this.klientyBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.klientyBindingNavigator.Size = new System.Drawing.Size(630, 25);
            this.klientyBindingNavigator.TabIndex = 0;
            this.klientyBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // klientyBindingNavigatorSaveItem
            // 
            this.klientyBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.klientyBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("klientyBindingNavigatorSaveItem.Image")));
            this.klientyBindingNavigatorSaveItem.Name = "klientyBindingNavigatorSaveItem";
            this.klientyBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.klientyBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.klientyBindingNavigatorSaveItem.Click += new System.EventHandler(this.klientyBindingNavigatorSaveItem_Click);
            // 
            // klientyDataGridView
            // 
            this.klientyDataGridView.AutoGenerateColumns = false;
            this.klientyDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.klientyDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.klientyDataGridView.DataSource = this.klientyBindingSource;
            this.klientyDataGridView.Location = new System.Drawing.Point(12, 49);
            this.klientyDataGridView.Name = "klientyDataGridView";
            this.klientyDataGridView.Size = new System.Drawing.Size(443, 111);
            this.klientyDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id_klient";
            this.dataGridViewTextBoxColumn1.HeaderText = "Id_klient";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "FIO";
            this.dataGridViewTextBoxColumn2.HeaderText = "FIO";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Pol";
            this.dataGridViewTextBoxColumn3.HeaderText = "Pol";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Data_rozhdeniya";
            this.dataGridViewTextBoxColumn4.HeaderText = "Data_rozhdeniya";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // button_pervaya
            // 
            this.button_pervaya.BackColor = System.Drawing.Color.LightSalmon;
            this.button_pervaya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_pervaya.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_pervaya.Location = new System.Drawing.Point(59, 361);
            this.button_pervaya.Name = "button_pervaya";
            this.button_pervaya.Size = new System.Drawing.Size(125, 50);
            this.button_pervaya.TabIndex = 2;
            this.button_pervaya.Text = "Первая";
            this.button_pervaya.UseVisualStyleBackColor = false;
            this.button_pervaya.Click += new System.EventHandler(this.button_pervaya_Click);
            // 
            // button_posled
            // 
            this.button_posled.BackColor = System.Drawing.Color.LightSalmon;
            this.button_posled.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_posled.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_posled.Location = new System.Drawing.Point(321, 361);
            this.button_posled.Name = "button_posled";
            this.button_posled.Size = new System.Drawing.Size(125, 50);
            this.button_posled.TabIndex = 3;
            this.button_posled.Text = "Последняя";
            this.button_posled.UseVisualStyleBackColor = false;
            this.button_posled.Click += new System.EventHandler(this.button_posled_Click);
            // 
            // button_pred
            // 
            this.button_pred.BackColor = System.Drawing.Color.LightSalmon;
            this.button_pred.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_pred.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_pred.Location = new System.Drawing.Point(452, 361);
            this.button_pred.Name = "button_pred";
            this.button_pred.Size = new System.Drawing.Size(131, 50);
            this.button_pred.TabIndex = 4;
            this.button_pred.Text = "Предыдущая";
            this.button_pred.UseVisualStyleBackColor = false;
            this.button_pred.Click += new System.EventHandler(this.button_pred_Click);
            // 
            // button_sled
            // 
            this.button_sled.BackColor = System.Drawing.Color.LightSalmon;
            this.button_sled.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_sled.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_sled.Location = new System.Drawing.Point(190, 361);
            this.button_sled.Name = "button_sled";
            this.button_sled.Size = new System.Drawing.Size(125, 50);
            this.button_sled.TabIndex = 5;
            this.button_sled.Text = "Следующая";
            this.button_sled.UseVisualStyleBackColor = false;
            this.button_sled.Click += new System.EventHandler(this.button_sled_Click);
            // 
            // button_dobavit
            // 
            this.button_dobavit.BackColor = System.Drawing.Color.LightSalmon;
            this.button_dobavit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_dobavit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_dobavit.Location = new System.Drawing.Point(321, 417);
            this.button_dobavit.Name = "button_dobavit";
            this.button_dobavit.Size = new System.Drawing.Size(125, 50);
            this.button_dobavit.TabIndex = 6;
            this.button_dobavit.Text = "Добавить";
            this.button_dobavit.UseVisualStyleBackColor = false;
            this.button_dobavit.Click += new System.EventHandler(this.button_dobavit_Click);
            // 
            // button_ydalit
            // 
            this.button_ydalit.BackColor = System.Drawing.Color.LightSalmon;
            this.button_ydalit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ydalit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_ydalit.Location = new System.Drawing.Point(190, 417);
            this.button_ydalit.Name = "button_ydalit";
            this.button_ydalit.Size = new System.Drawing.Size(125, 50);
            this.button_ydalit.TabIndex = 7;
            this.button_ydalit.Text = "Удалить";
            this.button_ydalit.UseVisualStyleBackColor = false;
            this.button_ydalit.Click += new System.EventHandler(this.button_ydalit_Click);
            // 
            // button_sohranit
            // 
            this.button_sohranit.BackColor = System.Drawing.Color.LightSalmon;
            this.button_sohranit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_sohranit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_sohranit.Location = new System.Drawing.Point(59, 417);
            this.button_sohranit.Name = "button_sohranit";
            this.button_sohranit.Size = new System.Drawing.Size(125, 50);
            this.button_sohranit.TabIndex = 8;
            this.button_sohranit.Text = "Сохранить";
            this.button_sohranit.UseVisualStyleBackColor = false;
            this.button_sohranit.Click += new System.EventHandler(this.button_sohranit_Click);
            // 
            // button_nazad
            // 
            this.button_nazad.BackColor = System.Drawing.Color.LightSalmon;
            this.button_nazad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_nazad.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_nazad.Location = new System.Drawing.Point(452, 417);
            this.button_nazad.Name = "button_nazad";
            this.button_nazad.Size = new System.Drawing.Size(131, 50);
            this.button_nazad.TabIndex = 9;
            this.button_nazad.Text = "Назад";
            this.button_nazad.UseVisualStyleBackColor = false;
            this.button_nazad.Click += new System.EventHandler(this.button_nazad_Click);
            // 
            // button_filtr
            // 
            this.button_filtr.BackColor = System.Drawing.Color.LightSalmon;
            this.button_filtr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_filtr.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_filtr.Location = new System.Drawing.Point(495, 306);
            this.button_filtr.Name = "button_filtr";
            this.button_filtr.Size = new System.Drawing.Size(109, 30);
            this.button_filtr.TabIndex = 10;
            this.button_filtr.Text = "Поиск";
            this.button_filtr.UseVisualStyleBackColor = false;
            this.button_filtr.Click += new System.EventHandler(this.button_filtr_Click);
            // 
            // button_sort
            // 
            this.button_sort.BackColor = System.Drawing.Color.LightSalmon;
            this.button_sort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_sort.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_sort.Location = new System.Drawing.Point(494, 151);
            this.button_sort.Name = "button_sort";
            this.button_sort.Size = new System.Drawing.Size(109, 30);
            this.button_sort.TabIndex = 11;
            this.button_sort.Text = "Сортировать";
            this.button_sort.UseVisualStyleBackColor = false;
            this.button_sort.Click += new System.EventHandler(this.button_naiti_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(500, 39);
            this.label1.MaximumSize = new System.Drawing.Size(110, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 76);
            this.label1.TabIndex = 12;
            this.label1.Text = "Введите название столбца для сортировки";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(498, 213);
            this.label2.MaximumSize = new System.Drawing.Size(110, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 57);
            this.label2.TabIndex = 13;
            this.label2.Text = "Введите ФИО клиента для поиска";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbPoisk
            // 
            this.tbPoisk.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbPoisk.Location = new System.Drawing.Point(494, 118);
            this.tbPoisk.Name = "tbPoisk";
            this.tbPoisk.Size = new System.Drawing.Size(109, 27);
            this.tbPoisk.TabIndex = 14;
            // 
            // tbFiltr
            // 
            this.tbFiltr.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbFiltr.Location = new System.Drawing.Point(495, 273);
            this.tbFiltr.Name = "tbFiltr";
            this.tbFiltr.Size = new System.Drawing.Size(109, 27);
            this.tbFiltr.TabIndex = 15;
            // 
            // id_klientLabel
            // 
            id_klientLabel.AutoSize = true;
            id_klientLabel.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            id_klientLabel.Location = new System.Drawing.Point(65, 180);
            id_klientLabel.Name = "id_klientLabel";
            id_klientLabel.Size = new System.Drawing.Size(77, 23);
            id_klientLabel.TabIndex = 16;
            id_klientLabel.Text = "Id klient:";
            // 
            // id_klientTextBox
            // 
            this.id_klientTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.klientyBindingSource, "Id_klient", true));
            this.id_klientTextBox.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.id_klientTextBox.Location = new System.Drawing.Point(155, 177);
            this.id_klientTextBox.Name = "id_klientTextBox";
            this.id_klientTextBox.Size = new System.Drawing.Size(305, 31);
            this.id_klientTextBox.TabIndex = 17;
            // 
            // fIOLabel
            // 
            fIOLabel.AutoSize = true;
            fIOLabel.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            fIOLabel.Location = new System.Drawing.Point(99, 217);
            fIOLabel.Name = "fIOLabel";
            fIOLabel.Size = new System.Drawing.Size(43, 23);
            fIOLabel.TabIndex = 18;
            fIOLabel.Text = "FIO:";
            // 
            // fIOTextBox
            // 
            this.fIOTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.klientyBindingSource, "FIO", true));
            this.fIOTextBox.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.fIOTextBox.Location = new System.Drawing.Point(155, 214);
            this.fIOTextBox.Name = "fIOTextBox";
            this.fIOTextBox.Size = new System.Drawing.Size(305, 31);
            this.fIOTextBox.TabIndex = 19;
            // 
            // polLabel
            // 
            polLabel.AutoSize = true;
            polLabel.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            polLabel.Location = new System.Drawing.Point(103, 254);
            polLabel.Name = "polLabel";
            polLabel.Size = new System.Drawing.Size(39, 23);
            polLabel.TabIndex = 20;
            polLabel.Text = "Pol:";
            // 
            // polTextBox
            // 
            this.polTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.klientyBindingSource, "Pol", true));
            this.polTextBox.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.polTextBox.Location = new System.Drawing.Point(155, 251);
            this.polTextBox.Name = "polTextBox";
            this.polTextBox.Size = new System.Drawing.Size(305, 31);
            this.polTextBox.TabIndex = 21;
            // 
            // data_rozhdeniyaLabel
            // 
            data_rozhdeniyaLabel.AutoSize = true;
            data_rozhdeniyaLabel.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            data_rozhdeniyaLabel.Location = new System.Drawing.Point(8, 288);
            data_rozhdeniyaLabel.Name = "data_rozhdeniyaLabel";
            data_rozhdeniyaLabel.Size = new System.Drawing.Size(141, 23);
            data_rozhdeniyaLabel.TabIndex = 22;
            data_rozhdeniyaLabel.Text = "Data rozhdeniya:";
            // 
            // data_rozhdeniyaDateTimePicker
            // 
            this.data_rozhdeniyaDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.klientyBindingSource, "Data_rozhdeniya", true));
            this.data_rozhdeniyaDateTimePicker.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.data_rozhdeniyaDateTimePicker.Location = new System.Drawing.Point(155, 288);
            this.data_rozhdeniyaDateTimePicker.Name = "data_rozhdeniyaDateTimePicker";
            this.data_rozhdeniyaDateTimePicker.Size = new System.Drawing.Size(305, 31);
            this.data_rozhdeniyaDateTimePicker.TabIndex = 23;
            // 
            // Admin_klienty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(630, 481);
            this.Controls.Add(id_klientLabel);
            this.Controls.Add(this.id_klientTextBox);
            this.Controls.Add(fIOLabel);
            this.Controls.Add(this.fIOTextBox);
            this.Controls.Add(polLabel);
            this.Controls.Add(this.polTextBox);
            this.Controls.Add(data_rozhdeniyaLabel);
            this.Controls.Add(this.data_rozhdeniyaDateTimePicker);
            this.Controls.Add(this.tbFiltr);
            this.Controls.Add(this.tbPoisk);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_sort);
            this.Controls.Add(this.button_filtr);
            this.Controls.Add(this.button_nazad);
            this.Controls.Add(this.button_sohranit);
            this.Controls.Add(this.button_ydalit);
            this.Controls.Add(this.button_dobavit);
            this.Controls.Add(this.button_sled);
            this.Controls.Add(this.button_pred);
            this.Controls.Add(this.button_posled);
            this.Controls.Add(this.button_pervaya);
            this.Controls.Add(this.klientyDataGridView);
            this.Controls.Add(this.klientyBindingNavigator);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Admin_klienty";
            this.Text = "Клиенты";
            this.Load += new System.EventHandler(this.Admin_klienty_Load);
            ((System.ComponentModel.ISupportInitialize)(this._DE_Astahov__3DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientyBindingNavigator)).EndInit();
            this.klientyBindingNavigator.ResumeLayout(false);
            this.klientyBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.klientyDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private _DE_Astahov__3DataSet _DE_Astahov__3DataSet;
        private System.Windows.Forms.BindingSource klientyBindingSource;
        private _DE_Astahov__3DataSetTableAdapters.KlientyTableAdapter klientyTableAdapter;
        private _DE_Astahov__3DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator klientyBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton klientyBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView klientyDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Button button_pervaya;
        private System.Windows.Forms.Button button_posled;
        private System.Windows.Forms.Button button_pred;
        private System.Windows.Forms.Button button_sled;
        private System.Windows.Forms.Button button_dobavit;
        private System.Windows.Forms.Button button_ydalit;
        private System.Windows.Forms.Button button_sohranit;
        private System.Windows.Forms.Button button_nazad;
        private System.Windows.Forms.Button button_filtr;
        private System.Windows.Forms.Button button_sort;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbPoisk;
        private System.Windows.Forms.TextBox tbFiltr;
        private System.Windows.Forms.TextBox id_klientTextBox;
        private System.Windows.Forms.TextBox fIOTextBox;
        private System.Windows.Forms.TextBox polTextBox;
        private System.Windows.Forms.DateTimePicker data_rozhdeniyaDateTimePicker;
    }
}