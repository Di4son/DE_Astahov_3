﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DE_Astahov_3
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void button_pokypki_Click(object sender, EventArgs e)
        {
            Admin_pokypki ap = new Admin_pokypki();
            ap.Show();
            this.Hide();
        }

        private void button_klienty_Click(object sender, EventArgs e)
        {
            Admin_klienty ak = new Admin_klienty();
            ak.Show();
            this.Hide();
        }

        private void button_tovary_Click(object sender, EventArgs e)
        {
            Admin_tovary at = new Admin_tovary();
            at.Show();
            this.Hide();
        }

        private void button_nazad_Click(object sender, EventArgs e)
        {
            Avtorizaciya avt = new Avtorizaciya();
            avt.Show();
            this.Hide();
        }
    }
}
