﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DE_Astahov_3
{
    public partial class User_tovary : Form
    {
        public User_tovary()
        {
            InitializeComponent();
        }

        private void tovaryBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tovaryBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._DE_Astahov__3DataSet);

        }

        private void User_tovary_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_DE_Astahov__3DataSet.Tovary". При необходимости она может быть перемещена или удалена.
            this.tovaryTableAdapter.Fill(this._DE_Astahov__3DataSet.Tovary);

        }

        private void button_sort_Click(object sender, EventArgs e)
        {
            tovaryBindingSource.Sort = tbPoisk.Text + " Desc";
        }

        private void button_filtr_Click(object sender, EventArgs e)
        {
            tovaryBindingSource.Filter = "[Nazvaniye_tovara] LIKE '" + tbFiltr.Text + "%'";
        }
    }
}
