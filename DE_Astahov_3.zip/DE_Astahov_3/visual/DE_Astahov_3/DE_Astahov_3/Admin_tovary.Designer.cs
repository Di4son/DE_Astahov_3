﻿namespace DE_Astahov_3
{
    partial class Admin_tovary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin_tovary));
            this.button_nazad = new System.Windows.Forms.Button();
            this.button_sohranit = new System.Windows.Forms.Button();
            this.button_ydalit = new System.Windows.Forms.Button();
            this.button_dobavit = new System.Windows.Forms.Button();
            this.button_sled = new System.Windows.Forms.Button();
            this.button_pred = new System.Windows.Forms.Button();
            this.button_posled = new System.Windows.Forms.Button();
            this.button_pervaya = new System.Windows.Forms.Button();
            this._DE_Astahov__3DataSet = new DE_Astahov_3._DE_Astahov__3DataSet();
            this.tovaryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tovaryTableAdapter = new DE_Astahov_3._DE_Astahov__3DataSetTableAdapters.TovaryTableAdapter();
            this.tableAdapterManager = new DE_Astahov_3._DE_Astahov__3DataSetTableAdapters.TableAdapterManager();
            this.tovaryBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tovaryBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.tovaryDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this._DE_Astahov__3DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tovaryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tovaryBindingNavigator)).BeginInit();
            this.tovaryBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tovaryDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // button_nazad
            // 
            this.button_nazad.BackColor = System.Drawing.Color.LightSalmon;
            this.button_nazad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_nazad.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_nazad.Location = new System.Drawing.Point(416, 214);
            this.button_nazad.Name = "button_nazad";
            this.button_nazad.Size = new System.Drawing.Size(125, 50);
            this.button_nazad.TabIndex = 25;
            this.button_nazad.Text = "Назад";
            this.button_nazad.UseVisualStyleBackColor = false;
            this.button_nazad.Click += new System.EventHandler(this.button_nazad_Click);
            // 
            // button_sohranit
            // 
            this.button_sohranit.BackColor = System.Drawing.Color.LightSalmon;
            this.button_sohranit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_sohranit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_sohranit.Location = new System.Drawing.Point(285, 157);
            this.button_sohranit.Name = "button_sohranit";
            this.button_sohranit.Size = new System.Drawing.Size(125, 50);
            this.button_sohranit.TabIndex = 24;
            this.button_sohranit.Text = "Сохранить";
            this.button_sohranit.UseVisualStyleBackColor = false;
            this.button_sohranit.Click += new System.EventHandler(this.button_sohranit_Click);
            // 
            // button_ydalit
            // 
            this.button_ydalit.BackColor = System.Drawing.Color.LightSalmon;
            this.button_ydalit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ydalit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_ydalit.Location = new System.Drawing.Point(285, 214);
            this.button_ydalit.Name = "button_ydalit";
            this.button_ydalit.Size = new System.Drawing.Size(125, 50);
            this.button_ydalit.TabIndex = 23;
            this.button_ydalit.Text = "Удалить";
            this.button_ydalit.UseVisualStyleBackColor = false;
            this.button_ydalit.Click += new System.EventHandler(this.button_ydalit_Click);
            // 
            // button_dobavit
            // 
            this.button_dobavit.BackColor = System.Drawing.Color.LightSalmon;
            this.button_dobavit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_dobavit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_dobavit.Location = new System.Drawing.Point(416, 158);
            this.button_dobavit.Name = "button_dobavit";
            this.button_dobavit.Size = new System.Drawing.Size(125, 50);
            this.button_dobavit.TabIndex = 22;
            this.button_dobavit.Text = "Добавить";
            this.button_dobavit.UseVisualStyleBackColor = false;
            this.button_dobavit.Click += new System.EventHandler(this.button_dobavit_Click);
            // 
            // button_sled
            // 
            this.button_sled.BackColor = System.Drawing.Color.LightSalmon;
            this.button_sled.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_sled.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_sled.Location = new System.Drawing.Point(145, 157);
            this.button_sled.Name = "button_sled";
            this.button_sled.Size = new System.Drawing.Size(134, 50);
            this.button_sled.TabIndex = 21;
            this.button_sled.Text = "Следующая";
            this.button_sled.UseVisualStyleBackColor = false;
            this.button_sled.Click += new System.EventHandler(this.button_sled_Click);
            // 
            // button_pred
            // 
            this.button_pred.BackColor = System.Drawing.Color.LightSalmon;
            this.button_pred.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_pred.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_pred.Location = new System.Drawing.Point(145, 214);
            this.button_pred.Name = "button_pred";
            this.button_pred.Size = new System.Drawing.Size(134, 50);
            this.button_pred.TabIndex = 20;
            this.button_pred.Text = "Предыдущая";
            this.button_pred.UseVisualStyleBackColor = false;
            this.button_pred.Click += new System.EventHandler(this.button_pred_Click);
            // 
            // button_posled
            // 
            this.button_posled.BackColor = System.Drawing.Color.LightSalmon;
            this.button_posled.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_posled.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_posled.Location = new System.Drawing.Point(12, 213);
            this.button_posled.Name = "button_posled";
            this.button_posled.Size = new System.Drawing.Size(125, 50);
            this.button_posled.TabIndex = 19;
            this.button_posled.Text = "Последняя";
            this.button_posled.UseVisualStyleBackColor = false;
            this.button_posled.Click += new System.EventHandler(this.button_posled_Click);
            // 
            // button_pervaya
            // 
            this.button_pervaya.BackColor = System.Drawing.Color.LightSalmon;
            this.button_pervaya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_pervaya.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_pervaya.Location = new System.Drawing.Point(12, 157);
            this.button_pervaya.Name = "button_pervaya";
            this.button_pervaya.Size = new System.Drawing.Size(125, 50);
            this.button_pervaya.TabIndex = 18;
            this.button_pervaya.Text = "Первая";
            this.button_pervaya.UseVisualStyleBackColor = false;
            this.button_pervaya.Click += new System.EventHandler(this.button_pervaya_Click);
            // 
            // _DE_Astahov__3DataSet
            // 
            this._DE_Astahov__3DataSet.DataSetName = "_DE_Astahov__3DataSet";
            this._DE_Astahov__3DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tovaryBindingSource
            // 
            this.tovaryBindingSource.DataMember = "Tovary";
            this.tovaryBindingSource.DataSource = this._DE_Astahov__3DataSet;
            // 
            // tovaryTableAdapter
            // 
            this.tovaryTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AvtorizacziyaTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.KlientyTableAdapter = null;
            this.tableAdapterManager.PokypkiTableAdapter = null;
            this.tableAdapterManager.TovaryTableAdapter = this.tovaryTableAdapter;
            this.tableAdapterManager.UpdateOrder = DE_Astahov_3._DE_Astahov__3DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tovaryBindingNavigator
            // 
            this.tovaryBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tovaryBindingNavigator.BindingSource = this.tovaryBindingSource;
            this.tovaryBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tovaryBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tovaryBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tovaryBindingNavigatorSaveItem});
            this.tovaryBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.tovaryBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tovaryBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tovaryBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tovaryBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tovaryBindingNavigator.Name = "tovaryBindingNavigator";
            this.tovaryBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tovaryBindingNavigator.Size = new System.Drawing.Size(553, 25);
            this.tovaryBindingNavigator.TabIndex = 26;
            this.tovaryBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tovaryBindingNavigatorSaveItem
            // 
            this.tovaryBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tovaryBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tovaryBindingNavigatorSaveItem.Image")));
            this.tovaryBindingNavigatorSaveItem.Name = "tovaryBindingNavigatorSaveItem";
            this.tovaryBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.tovaryBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.tovaryBindingNavigatorSaveItem.Click += new System.EventHandler(this.tovaryBindingNavigatorSaveItem_Click);
            // 
            // tovaryDataGridView
            // 
            this.tovaryDataGridView.AutoGenerateColumns = false;
            this.tovaryDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tovaryDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.tovaryDataGridView.DataSource = this.tovaryBindingSource;
            this.tovaryDataGridView.Location = new System.Drawing.Point(53, 28);
            this.tovaryDataGridView.Name = "tovaryDataGridView";
            this.tovaryDataGridView.Size = new System.Drawing.Size(443, 111);
            this.tovaryDataGridView.TabIndex = 26;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id_tovar";
            this.dataGridViewTextBoxColumn1.HeaderText = "Id_tovar";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Nazvaniye_tovara";
            this.dataGridViewTextBoxColumn2.HeaderText = "Nazvaniye_tovara";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Stoimost";
            this.dataGridViewTextBoxColumn3.HeaderText = "Stoimost";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "KolichestvoNaSklade";
            this.dataGridViewTextBoxColumn4.HeaderText = "KolichestvoNaSklade";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // Admin_tovary
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(553, 278);
            this.Controls.Add(this.tovaryDataGridView);
            this.Controls.Add(this.tovaryBindingNavigator);
            this.Controls.Add(this.button_nazad);
            this.Controls.Add(this.button_sohranit);
            this.Controls.Add(this.button_ydalit);
            this.Controls.Add(this.button_dobavit);
            this.Controls.Add(this.button_sled);
            this.Controls.Add(this.button_pred);
            this.Controls.Add(this.button_posled);
            this.Controls.Add(this.button_pervaya);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Admin_tovary";
            this.Text = "Товары";
            this.Load += new System.EventHandler(this.Admin_tovary_Load);
            ((System.ComponentModel.ISupportInitialize)(this._DE_Astahov__3DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tovaryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tovaryBindingNavigator)).EndInit();
            this.tovaryBindingNavigator.ResumeLayout(false);
            this.tovaryBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tovaryDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_nazad;
        private System.Windows.Forms.Button button_sohranit;
        private System.Windows.Forms.Button button_ydalit;
        private System.Windows.Forms.Button button_dobavit;
        private System.Windows.Forms.Button button_sled;
        private System.Windows.Forms.Button button_pred;
        private System.Windows.Forms.Button button_posled;
        private System.Windows.Forms.Button button_pervaya;
        private _DE_Astahov__3DataSet _DE_Astahov__3DataSet;
        private System.Windows.Forms.BindingSource tovaryBindingSource;
        private _DE_Astahov__3DataSetTableAdapters.TovaryTableAdapter tovaryTableAdapter;
        private _DE_Astahov__3DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator tovaryBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tovaryBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView tovaryDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    }
}