﻿namespace DE_Astahov_3
{
    partial class User_tovary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(User_tovary));
            this.button_nazad = new System.Windows.Forms.Button();
            this.button_sled = new System.Windows.Forms.Button();
            this.button_pred = new System.Windows.Forms.Button();
            this.button_posled = new System.Windows.Forms.Button();
            this.button_pervaya = new System.Windows.Forms.Button();
            this._DE_Astahov__3DataSet = new DE_Astahov_3._DE_Astahov__3DataSet();
            this.tovaryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tovaryTableAdapter = new DE_Astahov_3._DE_Astahov__3DataSetTableAdapters.TovaryTableAdapter();
            this.tableAdapterManager = new DE_Astahov_3._DE_Astahov__3DataSetTableAdapters.TableAdapterManager();
            this.tovaryDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbFiltr = new System.Windows.Forms.TextBox();
            this.tbPoisk = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button_sort = new System.Windows.Forms.Button();
            this.button_filtr = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this._DE_Astahov__3DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tovaryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tovaryDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // button_nazad
            // 
            this.button_nazad.BackColor = System.Drawing.Color.LightSalmon;
            this.button_nazad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_nazad.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_nazad.Location = new System.Drawing.Point(558, 247);
            this.button_nazad.Name = "button_nazad";
            this.button_nazad.Size = new System.Drawing.Size(125, 50);
            this.button_nazad.TabIndex = 43;
            this.button_nazad.Text = "Назад";
            this.button_nazad.UseVisualStyleBackColor = false;
            // 
            // button_sled
            // 
            this.button_sled.BackColor = System.Drawing.Color.LightSalmon;
            this.button_sled.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_sled.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_sled.Location = new System.Drawing.Point(287, 247);
            this.button_sled.Name = "button_sled";
            this.button_sled.Size = new System.Drawing.Size(125, 50);
            this.button_sled.TabIndex = 42;
            this.button_sled.Text = "Следующая";
            this.button_sled.UseVisualStyleBackColor = false;
            // 
            // button_pred
            // 
            this.button_pred.BackColor = System.Drawing.Color.LightSalmon;
            this.button_pred.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_pred.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_pred.Location = new System.Drawing.Point(418, 247);
            this.button_pred.Name = "button_pred";
            this.button_pred.Size = new System.Drawing.Size(134, 50);
            this.button_pred.TabIndex = 41;
            this.button_pred.Text = "Предыдущая";
            this.button_pred.UseVisualStyleBackColor = false;
            // 
            // button_posled
            // 
            this.button_posled.BackColor = System.Drawing.Color.LightSalmon;
            this.button_posled.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_posled.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_posled.Location = new System.Drawing.Point(156, 247);
            this.button_posled.Name = "button_posled";
            this.button_posled.Size = new System.Drawing.Size(125, 50);
            this.button_posled.TabIndex = 40;
            this.button_posled.Text = "Последняя";
            this.button_posled.UseVisualStyleBackColor = false;
            // 
            // button_pervaya
            // 
            this.button_pervaya.BackColor = System.Drawing.Color.LightSalmon;
            this.button_pervaya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_pervaya.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_pervaya.Location = new System.Drawing.Point(25, 247);
            this.button_pervaya.Name = "button_pervaya";
            this.button_pervaya.Size = new System.Drawing.Size(125, 50);
            this.button_pervaya.TabIndex = 39;
            this.button_pervaya.Text = "Первая";
            this.button_pervaya.UseVisualStyleBackColor = false;
            // 
            // _DE_Astahov__3DataSet
            // 
            this._DE_Astahov__3DataSet.DataSetName = "_DE_Astahov__3DataSet";
            this._DE_Astahov__3DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tovaryBindingSource
            // 
            this.tovaryBindingSource.DataMember = "Tovary";
            this.tovaryBindingSource.DataSource = this._DE_Astahov__3DataSet;
            // 
            // tovaryTableAdapter
            // 
            this.tovaryTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AvtorizacziyaTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.KlientyTableAdapter = null;
            this.tableAdapterManager.PokypkiTableAdapter = null;
            this.tableAdapterManager.TovaryTableAdapter = this.tovaryTableAdapter;
            this.tableAdapterManager.UpdateOrder = DE_Astahov_3._DE_Astahov__3DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tovaryDataGridView
            // 
            this.tovaryDataGridView.AutoGenerateColumns = false;
            this.tovaryDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tovaryDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.tovaryDataGridView.DataSource = this.tovaryBindingSource;
            this.tovaryDataGridView.Location = new System.Drawing.Point(12, 64);
            this.tovaryDataGridView.Name = "tovaryDataGridView";
            this.tovaryDataGridView.Size = new System.Drawing.Size(450, 111);
            this.tovaryDataGridView.TabIndex = 44;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id_tovar";
            this.dataGridViewTextBoxColumn1.HeaderText = "Id_tovar";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Nazvaniye_tovara";
            this.dataGridViewTextBoxColumn2.HeaderText = "Nazvaniye_tovara";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Stoimost";
            this.dataGridViewTextBoxColumn3.HeaderText = "Stoimost";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "KolichestvoNaSklade";
            this.dataGridViewTextBoxColumn4.HeaderText = "KolichestvoNaSklade";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // tbFiltr
            // 
            this.tbFiltr.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbFiltr.Location = new System.Drawing.Point(510, 157);
            this.tbFiltr.Name = "tbFiltr";
            this.tbFiltr.Size = new System.Drawing.Size(164, 27);
            this.tbFiltr.TabIndex = 50;
            // 
            // tbPoisk
            // 
            this.tbPoisk.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbPoisk.Location = new System.Drawing.Point(510, 64);
            this.tbPoisk.Name = "tbPoisk";
            this.tbPoisk.Size = new System.Drawing.Size(164, 27);
            this.tbPoisk.TabIndex = 49;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(465, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(241, 19);
            this.label2.TabIndex = 48;
            this.label2.Text = "Введите ФИО клиента для поиска";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(488, 23);
            this.label1.MaximumSize = new System.Drawing.Size(200, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 38);
            this.label1.TabIndex = 47;
            this.label1.Text = "Введите название столбца для сортировки";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button_sort
            // 
            this.button_sort.BackColor = System.Drawing.Color.LightSalmon;
            this.button_sort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_sort.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_sort.Location = new System.Drawing.Point(542, 97);
            this.button_sort.Name = "button_sort";
            this.button_sort.Size = new System.Drawing.Size(109, 30);
            this.button_sort.TabIndex = 46;
            this.button_sort.Text = "Сортировать";
            this.button_sort.UseVisualStyleBackColor = false;
            this.button_sort.Click += new System.EventHandler(this.button_sort_Click);
            // 
            // button_filtr
            // 
            this.button_filtr.BackColor = System.Drawing.Color.LightSalmon;
            this.button_filtr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_filtr.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_filtr.Location = new System.Drawing.Point(542, 190);
            this.button_filtr.Name = "button_filtr";
            this.button_filtr.Size = new System.Drawing.Size(109, 30);
            this.button_filtr.TabIndex = 45;
            this.button_filtr.Text = "Поиск";
            this.button_filtr.UseVisualStyleBackColor = false;
            this.button_filtr.Click += new System.EventHandler(this.button_filtr_Click);
            // 
            // User_tovary
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(713, 314);
            this.Controls.Add(this.tbFiltr);
            this.Controls.Add(this.tbPoisk);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_sort);
            this.Controls.Add(this.button_filtr);
            this.Controls.Add(this.tovaryDataGridView);
            this.Controls.Add(this.button_nazad);
            this.Controls.Add(this.button_sled);
            this.Controls.Add(this.button_pred);
            this.Controls.Add(this.button_posled);
            this.Controls.Add(this.button_pervaya);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "User_tovary";
            this.Text = "Товары";
            this.Load += new System.EventHandler(this.User_tovary_Load);
            ((System.ComponentModel.ISupportInitialize)(this._DE_Astahov__3DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tovaryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tovaryDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_nazad;
        private System.Windows.Forms.Button button_sled;
        private System.Windows.Forms.Button button_pred;
        private System.Windows.Forms.Button button_posled;
        private System.Windows.Forms.Button button_pervaya;
        private _DE_Astahov__3DataSet _DE_Astahov__3DataSet;
        private System.Windows.Forms.BindingSource tovaryBindingSource;
        private _DE_Astahov__3DataSetTableAdapters.TovaryTableAdapter tovaryTableAdapter;
        private _DE_Astahov__3DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView tovaryDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.TextBox tbFiltr;
        private System.Windows.Forms.TextBox tbPoisk;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_sort;
        private System.Windows.Forms.Button button_filtr;
    }
}