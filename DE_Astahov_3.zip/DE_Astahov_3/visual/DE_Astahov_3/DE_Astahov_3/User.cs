﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DE_Astahov_3
{
    public partial class User : Form
    {
        public User()
        {
            InitializeComponent();
        }

        private void button_klienty_Click(object sender, EventArgs e)
        {
            User_klienty uk = new User_klienty();
            uk.Show();
            this.Hide();
        }

        private void button_pokypki_Click(object sender, EventArgs e)
        {
            User_pokypki up = new User_pokypki();
            up.Show();
            this.Hide();
        }

        private void button_tovary_Click(object sender, EventArgs e)
        {
            User_tovary ut = new User_tovary();
            ut.Show();
            this.Hide();
        }
    }
}
