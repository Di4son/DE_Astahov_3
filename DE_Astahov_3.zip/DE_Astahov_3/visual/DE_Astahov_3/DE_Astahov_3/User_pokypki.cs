﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DE_Astahov_3
{
    public partial class User_pokypki : Form
    {
        public User_pokypki()
        {
            InitializeComponent();
        }

        private void pokypkiBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.pokypkiBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._DE_Astahov__3DataSet);

        }

        private void User_pokypki_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_DE_Astahov__3DataSet.Pokypki". При необходимости она может быть перемещена или удалена.
            this.pokypkiTableAdapter.Fill(this._DE_Astahov__3DataSet.Pokypki);

        }

        private void button_pervaya_Click(object sender, EventArgs e)
        {
            pokypkiBindingSource.MoveFirst();
        }

        private void button_sled_Click(object sender, EventArgs e)
        {
            pokypkiBindingSource.MoveNext();
        }

        private void button_posled_Click(object sender, EventArgs e)
        {
            pokypkiBindingSource.MoveLast();
        }

        private void button_pred_Click(object sender, EventArgs e)
        {
            pokypkiBindingSource.MovePrevious();
        }

        private void button_nazad_Click(object sender, EventArgs e)
        {
            User us = new User();
            us.Show();
            this.Hide();
        }
    }
}
