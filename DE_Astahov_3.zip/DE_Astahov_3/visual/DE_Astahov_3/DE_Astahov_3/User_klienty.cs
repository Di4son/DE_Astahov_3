﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DE_Astahov_3
{
    public partial class User_klienty : Form
    {
        public User_klienty()
        {
            InitializeComponent();
        }

        private void klientyBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.klientyBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._DE_Astahov__3DataSet);

        }

        private void User_klienty_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_DE_Astahov__3DataSet.Klienty". При необходимости она может быть перемещена или удалена.
            this.klientyTableAdapter.Fill(this._DE_Astahov__3DataSet.Klienty);

        }

        private void button_pervaya_Click(object sender, EventArgs e)
        {
            klientyBindingSource.MoveFirst();
        }

        private void button_posled_Click(object sender, EventArgs e)
        {
            klientyBindingSource.MoveLast();
        }

        private void button_sled_Click(object sender, EventArgs e)
        {
            klientyBindingSource.MoveNext();
        }

        private void button_pred_Click(object sender, EventArgs e)
        {
            klientyBindingSource.MovePrevious();
        }

        private void button_nazad_Click(object sender, EventArgs e)
        {
            User us = new User();
            us.Show();
            this.Hide();
        }

        private void поискКлиентаToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.klientyTableAdapter.ПоискКлиента(this._DE_Astahov__3DataSet.Klienty);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
